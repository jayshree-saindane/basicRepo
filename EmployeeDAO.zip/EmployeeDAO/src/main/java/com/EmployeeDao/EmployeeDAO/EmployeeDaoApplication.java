package com.EmployeeDao.EmployeeDAO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
@EntityScan("com")
@ComponentScan("com")
@SpringBootApplication
public class EmployeeDaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeDaoApplication.class, args);
		
		System.out.println("Hello Maharashtra");
	}

}
