package com.employee.dao;

import java.sql.*;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.employee.entity.Employee;
@Repository
public class EmployeeDAO {
	public ArrayList<Employee> getAllEmployees()
	{
		ArrayList<Employee> arrayList=new ArrayList<Employee>();
		
		try
		{
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3307/mydata1","root","root");
			
			Statement statement=connection.createStatement();
		
			ResultSet resultset=statement.executeQuery("select * from employee");
			
			
			while(resultset.next())
			{
				int eid=resultset.getInt("eid");
				
				String ename=resultset.getString("ename");
				
				int salary=resultset.getInt("salary");
				
				Employee employee=new Employee();
				employee.setEid(eid);
				employee.setEname(ename);
				employee.setSalary(salary);
				
				arrayList.add(employee);
			}
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		return arrayList;

	}
	
	
	public void deleteEmployee(int eid)
	{
		try
		{
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3307/mydata1","root","root");
			
			Statement statement=connection.createStatement();
			
			statement.executeUpdate("delete from employee where eid="+eid);
			
				
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	
	public void saveEmployee(Employee employee)
	{
		try
		{
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3307/mydata1","root","root");
							
			PreparedStatement statement=connection.prepareStatement("insert into employee(eid,ename,salary) values(?,?,?)");
			

			statement.setInt(1, employee.getEid());
			statement.setString(2, employee.getEname());
			statement.setInt(3, employee.getSalary());

			
			statement.executeUpdate();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void updateEmployee(Employee employee) 
	{
		try
		{
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3307/mydata1","root","root");
							
			PreparedStatement statement=connection.prepareStatement("update employee set ename=? , salary=? where eid=?");
			
			statement.setString(1, employee.getEname());
			statement.setInt(2, employee.getSalary());
			statement.setInt(3, employee.getEid());
			
			statement.executeUpdate();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	

	public Employee getEmployee(int eid)
	{

		Employee employee=new Employee();
		
		try
		{
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3307/mydata1","root","root");
			
			Statement statement=connection.createStatement();
		
			ResultSet resultset=statement.executeQuery("select * from employee where eid="+eid);
			
			
			if(resultset.next())
			{
				
				String ename=resultset.getString("ename");
				
				int salary=resultset.getInt("salary");
				
				employee.setEid(eid);
				employee.setEname(ename);
				employee.setSalary(salary);
				
				
			}
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		return employee;

	}
	

}
