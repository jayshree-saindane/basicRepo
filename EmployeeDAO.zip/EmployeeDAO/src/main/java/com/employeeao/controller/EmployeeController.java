package com.employeeao.controller;

import java.util.ArrayList;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.employee.dao.EmployeeDAO;
import com.employee.entity.Employee;

@RestController
public class EmployeeController {

	

	@Autowired
	EmployeeDAO dao; // global variable
	
	
	ArrayList<Employee> arrayList=new ArrayList<Employee>();
	
	EmployeeController()
	{
		System.out.println("constructor called");
	}
	
	@PostConstruct
    public void showData()
    {	
		arrayList=dao.getAllEmployees();
    }
	
	@RequestMapping("getAllEmployees")
	public ModelAndView getAllEmployees()
	{	
	
		ArrayList<Employee> arrayList=dao.getAllEmployees();
				
		ModelAndView modelAndView =new ModelAndView();
		modelAndView.setViewName("employee");
		modelAndView.addObject("allEmployees",arrayList);
		
		return modelAndView;
		
	}
	
	@RequestMapping("deleteEmployee/{eid}")
	public ModelAndView deleteEmployee(@PathVariable int eid)
	{
		dao.deleteEmployee(eid);
		
		return getAllEmployees();
		
	}
	
	@RequestMapping("saveEmployee")
	public ModelAndView saveEmployee(Employee employee)
	{

		dao.saveEmployee(employee);
		
		return getAllEmployees();
		
	}
	
	@RequestMapping("updateEmployee")
	public ModelAndView updateEmployee(Employee employee)
	{
		System.out.println("Employee from browser is " + employee);
		
		dao.updateEmployee(employee);
		
		return getAllEmployees();
		
	}
	
	
	@RequestMapping("showEmployee/{eid}")
	public ModelAndView showEmployee(@PathVariable int eid)
	{

		ModelAndView modelAndView =new ModelAndView();
		
		modelAndView.setViewName("employee");
		
		Employee employee=dao.getEmployee(eid);
		
		modelAndView.addObject("employee",employee);
		
		ArrayList<Employee> arrayList = dao.getAllEmployees();
		
		modelAndView.addObject("allEmployees",arrayList);
		
		return modelAndView;
		
	}

	@RequestMapping("viewEmployee")
	public ModelAndView viewEmployee(int eid)
	{

		ModelAndView modelAndView =new ModelAndView();
		
		modelAndView.setViewName("employee");
		
		Employee employee=dao.getEmployee(eid);
		
		modelAndView.addObject("employee",employee);
		
		ArrayList<Employee> arrayList = dao.getAllEmployees();
		
		modelAndView.addObject("allEmployees",arrayList);
		
		return modelAndView;
		
	}
	
	@RequestMapping("showEmployee")
	public ModelAndView showEmployee()
	{
		ModelAndView modelAndView =new ModelAndView();
		
		modelAndView.setViewName("employee");
		
		modelAndView.addObject("message","welcome to employee management Application");
		
		modelAndView.addObject("allEmployees",arrayList);
		
		return  modelAndView;
	}


}
