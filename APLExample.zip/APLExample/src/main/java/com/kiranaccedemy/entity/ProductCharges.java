package com.kiranaccedemy.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="charges")
public class ProductCharges {
@Id
String productCategory;
int discount;
int gst;
int deliveryCharge;
public String getProductCategory() {
	return productCategory;
}
public void setProductCategory(String productCategory) {
	this.productCategory = productCategory;
}
public int getDiscount() {
	return discount;
}
public void setDiscount(int discount) {
	this.discount = discount;
}
public int getGst() {
	return gst;
}
public void setGst(int gst) {
	this.gst = gst;
}
public int getDeliveryCharge() {
	return deliveryCharge;
}
public void setDeliveryCharge(int deliveryCharge) {
	this.deliveryCharge = deliveryCharge;
}
@Override
public String toString() {
	return "ProductCharges [productCategory=" + productCategory + ", discount=" + discount + ", gst=" + gst
			+ ", deliveryCharge=" + deliveryCharge + "]";
}

}
