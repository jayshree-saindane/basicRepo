package com.kiranaccedemy.entity;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyWebController2 {
	@RequestMapping("sum")
	public ModelAndView sum(int firstnumber,int secondnumber)
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("input");
		mv.addObject("answer", (firstnumber+secondnumber));
		return mv;
		
	}

}
