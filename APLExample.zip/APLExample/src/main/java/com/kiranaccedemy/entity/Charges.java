package com.kiranaccedemy.entity;

public class Charges {
double gst;
double delivery;
public double getGst() {
	return gst;
}
public void setGst(double gst) {
	this.gst = gst;
}
public double getDelivery() {
	return delivery;
}
public void setDelivery(double delivery) {
	this.delivery = delivery;
}
@Override
public String toString() {
	return "charges [gst=" + gst + ", delivery=" + delivery + "]";
}
}
