package com.kiranaccedemy.controller;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.kiranaccedemy.entity.Staff;


@RestController
public class staffTest {
@Autowired
SessionFactory factory;
//Write an api to get all the staff record.
@GetMapping("getAllStaff")
public List<Staff> getAllStaff()
{
	Session session=factory.openSession();
    
	
	Criteria criteria=session.createCriteria(Staff.class);
	List <Staff> list= criteria.list();
	
	System.out.println(list.getClass().getName());
	
	return list;
	}

//Write an api to get record whose staffed in 3.

@GetMapping("getRecord")
public Staff getRecord(@PathVariable int staffid)
{
	Session session=factory.openSession();
	Staff staff=session.get(Staff.class,3);
	return staff;
}


//write an api to insert one staff member in table.
@PostMapping("saveStaff")
public Staff saveStaff(@RequestBody Staff staff)
{
	Session session=factory.openSession();
	session.save(staff);
	session.beginTransaction().commit();
	return staff;
}

//write an api to get the list of staff who is/are having salary more than 20000.
@GetMapping("getSalary")
public List<Staff> getSalary()
{
	Session session=factory.openSession();

	Criteria criteria=session.createCriteria(Staff.class);
	
	criteria.add(Restrictions.gt("salary",20000));
		
	List list=criteria.list();
	
	return list;
}

//write an api to get the list of staff who is/are having experience between than 10&20.

@GetMapping("getExperience")
public List<Staff> getExperience()
{
	Session session=factory.openSession();
	Criteria criteria=session.createCriteria(Staff.class);
	criteria.add(Restrictions.between("experience",10,20));
	List<Staff> list=criteria.list();	
	return list;
}

//write an api to update the salary for staff whose id is 4.
@PutMapping("updateStaff")
public Staff updateStaff(@RequestBody Staff staff)
{
Session session=factory.openSession();
session.update(staff);
session.beginTransaction().commit();
return staff;
}

//write an api to get staff information who is having max salary.
@GetMapping("getMaxSalary")
public Staff getMaxSalary()
{
	Session session=factory.openSession();
	Criteria criteria=session.createCriteria(Staff.class);
	criteria.setProjection(Projections.max("salary"));
	List<Integer>list=criteria.list();
	int maxSalary=list.get(0);
	Criteria criteria1=session.createCriteria(Staff.class);
	criteria1.add(Restrictions.eq("salary", maxSalary));
List<Staff>list1=criteria1.list();
	return list1.get(0);
}

//write an api to get the list of staff whose are having profile as a trainer
@RequestMapping("getEqualTrainer")
public List<Staff> getEqualTrainer()
{
	Session session=factory.openSession();
	Criteria criteria=session.createCriteria(Staff.class);
	criteria.add(Restrictions.eq("profile", "trainer"));
	List<Staff>list=criteria.list();
	return list;
}
////write an api to get the list of staff whose not having profile as a trainer

@RequestMapping("getNotEqualTrainer")
public List<Staff> getNotEqualTrainer()
{
	Session session=factory.openSession();
	Criteria criteria=session.createCriteria(Staff.class);
	criteria.add(Restrictions.ne("profile", "trainer"));
	List<Staff>list=criteria.list();
	return list;
}
@RequestMapping("getminEx")
public List<Staff> getminEx()
{
	Session session=factory.openSession();
	Criteria criteria=session.createCriteria(Staff.class);
criteria.setProjection(Projections.min("experience"));
List<Staff>list=criteria.list();
return list;
}
}
