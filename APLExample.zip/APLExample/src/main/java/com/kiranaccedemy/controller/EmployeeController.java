package com.kiranaccedemy.controller;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class EmployeeController {
	@Autowired	
	SessionFactory factory;
	// Type URL localhost:8080/getEmployee in a browser to call below method
	
	@GetMapping("getEmployee")
public Employee getEmployee()
{
Session session=factory.openSession();
//session ==> [ get() , load() ] Session object

		// java.lang.Class
		// java.lang.String
		
		// get(Class c , int i)

Employee employee=session.get(Employee.class,102);
//employee==>[eid=101 name=suresh salary=60000 getEid()] Employee class object given by get() method

		// In advance java , object is given to us . NO need to create it . BUT we need to define reference
		
		// Account account=new Account(102,90000)  In Core java we create object and we create reference also
		
return employee;

}
	@PostMapping("saveEmployee")
	public Employee saveEmployee(@RequestBody Employee employee )
	{
		System.out.println("it is postman added in to Employee object");
		System.out.println(employee);
	Session session=factory.openSession();
	session.save(employee);
	session.beginTransaction().commit();
	return employee;
}
	// localhost:8080/deleteEmployee/115
	@DeleteMapping("deleteEmployee/{eid}")
	public Employee deleteEmployee(@PathVariable int eid)
	{
		Session session=factory.openSession();
		Employee employee=session.get(Employee.class, eid);
		session.delete(employee);
		session.beginTransaction().commit();
		return employee;
		
	}
	@PutMapping("updateEmployee")
	public Employee updateEmployee (@RequestBody Employee employee)
	{
		System.out.println("it is postmant update into employee database");
		System.out.println(employee);
		Session session=factory.openSession();
		session.update(employee);
		session.beginTransaction().commit();
		return employee;
	}
	
	//	// Criteria is used to fetch data from database , based on some conditions
	
	@GetMapping("getAllEmployee")
public List<Employee> getAllEmployee()
	{
		Session session=factory.openSession();
        
		
		Criteria criteria=session.createCriteria(Employee.class);
		List <Employee> list= criteria.list();
		
		System.out.println(list.getClass().getName());
		
		return list;
		
	}
}