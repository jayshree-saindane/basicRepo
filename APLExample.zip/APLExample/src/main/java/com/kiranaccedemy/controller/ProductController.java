package com.kiranaccedemy.controller;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kiranaccedemy.entity.Bill;
import com.kiranaccedemy.entity.Charges;
import com.kiranaccedemy.entity.ProductCharges;
import com.kiranaccedemy.entity.product;

@RestController
public class ProductController {
@Autowired
SessionFactory factory;
@RequestMapping("getProduct/{productId}")
public Bill getProduct(@PathVariable int productId)
{
	Session session=factory.openSession();
	product product=session.load(product.class, productId);
	Bill bill=new Bill();
	bill.setProductId(product.getProductId());
	bill.setName(product.getProductName());
	bill.setProductType(product.getProductType());
	bill.setCategory(product.getProductCategory());
	bill.setBasePrice(product.getProductPrice());
	String category=product.getProductCategory();
	ProductCharges pc=session.load(ProductCharges.class,category);
	double basePrice=product.getProductPrice();

	double discountamount=basePrice*(pc.getDiscount()/100);

	bill.setDiscount(discountamount);
	Charges charges=new Charges();
	charges.setDelivery(pc.getDeliveryCharge());
	double gstper=pc.getGst();
	double gstamount=basePrice*(gstper/100);
	charges.setGst(gstamount);
	bill.setCharges(charges);//setting charges
	double finalPrice=basePrice-discountamount+(pc.getDeliveryCharge()+gstamount);
	System.out.println(finalPrice);
	bill.setFinalPrice(finalPrice);
	return bill;
	
}
}
