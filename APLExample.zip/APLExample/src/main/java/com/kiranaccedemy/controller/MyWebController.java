package com.kiranaccedemy.controller;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.kiranaccedemy.entity.User;

@Controller
public class MyWebController 
{
	@Autowired
	SessionFactory factory;
	
	
	@RequestMapping("hello")
	public String hello()
	{
		return "hello";  // here hello is jsp page name
	}
	

	@RequestMapping("hi")
	public String hi()
	{
		return "hi";  // here hi is jsp page name
	}
	
	// MVC => model , view , controller
	@RequestMapping("add")
	ModelAndView add(Integer number1,Integer number2)
	{
		System.out.println(number1 + " " + number2);
		int sum = number1+number2;
		
		ModelAndView modelandview=new ModelAndView();
		
		modelandview.setViewName("result"); // view page name means JSP page name
		
		modelandview.addObject("data",sum); // here data attribute represents data which will be displayed on view page . here data is called model attribute
				
		return modelandview;
	}
	
	
	@RequestMapping("register")
	public String register()
	{
		return "register";  // here register is jsp page name
	}
	
	// User class's object will be created automatically and it will have data  coming from browser
	
	@RequestMapping("saveUserData")
	public ModelAndView saveUserData(User userfrombrowser,HttpServletRequest request)
	{

		MultipartFile filedata=userfrombrowser.getImages();
			
		// MultipartFile object contains image data
		
		String filename=filedata.getOriginalFilename();
		
		System.out.println(filename);// xyz.jpg
				
		File file=new File(request.getServletContext().getRealPath("/images"),filename);
				
		try 
		{
			
			filedata.transferTo(file);
			
			System.out.println("File uploaded successfully");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		ModelAndView modelandview=new ModelAndView();

		Session session=factory.openSession();
				
		Transaction tx=session.beginTransaction();
		
			userfrombrowser.setImagepath(filename);
			
			session.save(userfrombrowser);
		
		tx.commit();
				
		modelandview.addObject("message","Registration successful . pls login now"); 
						
		modelandview.setViewName("login"); // view page name means JSP page name
	
		return modelandview;
	}
	
	// localhost:8080/login
	@RequestMapping("login")
	public String login()
	{
		return "login";  // here login is jsp page name
	}
	
	
	@RequestMapping("validate")
	public ModelAndView validate(String username,String password)
	{
		ModelAndView modelandview=new ModelAndView();
		
		Session session=factory.openSession();

		User userfromdb=session.get(User.class,username);
			
		if(userfromdb==null)
		{
			modelandview.setViewName("login"); // view page name means JSP page name
			modelandview.addObject("message","wrong username"); // here message attribute represents data which will be displayed on view page . here message is called model attribute
			
		}
		
		else if(userfromdb.password.equals(password))
		{
			modelandview.setViewName("welcome"); // view page name means JSP page name
			
			List<User> list=session.createCriteria(User.class).list();
			
			modelandview.addObject("imagename",userfromdb.imagepath); 
			
			modelandview.addObject("usersfromdb",list); // here username attribute represents data which will be displayed on view page . here username is called model attribute
			
		}
		
		else
		{
			modelandview.setViewName("login"); // view page name means JSP page name
			modelandview.addObject("message","wrong password"); // here message attribute represents data which will be displayed on view page . here message is called model attribute
		}
		
		return modelandview;
	
	
	}
	

}
