package com.kiranaccademy.APLExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com")
@EntityScan("com")

public class AplExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(AplExampleApplication.class, args);
		System.out.println("i m jayu");
		}
	


}
