package com.accountdao.packages;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import java.sql.*;
import com.account.enttity.Account;
@Repository

public class AccountDao {


		public ArrayList<Account> getAllAccounts()
		{
			ArrayList<Account> arrayList=new ArrayList<Account>();
			
			try
			{
				Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3307/mydata","root","root");
				
				Statement statement=connection.createStatement();
			
				ResultSet resultset=statement.executeQuery("select * from account");
				
				
				while(resultset.next())
				{
					int acno=resultset.getInt("acno");
					String acholdernm=resultset.getString("acholdernm");
					int balance=resultset.getInt("balance");
					String date=resultset.getString("date");
					long mobno=resultset.getLong("mobno");
					long adharno=resultset.getLong("adharno");
					String emailid=resultset.getString("emailid");
					String imagepath=resultset.getString("imagepath");


 Account account=new Account();
					account.setAcno(acno);
					account.setAcholdernm(acholdernm);
					account.setBalance(balance);
					account.setDate(date);
					account.setMobno(mobno);
					account.setAdharno(adharno);
					account.setEmailid(emailid);
					account.setImagepath(imagepath);
					
					
					arrayList.add(account);
				}
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			
			return arrayList;
	
		}
		
		
		public void deleteAccount(int acno)
		{
			try
			{
				Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3307/mydata","root","root");
				
				Statement statement=connection.createStatement();
				
				statement.executeUpdate("delete from account where acno="+acno);
				
					
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}

		
		public void saveAccount(Account account)
		{
			try
			{
				Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3307/mydata","root","root");
								
				PreparedStatement statement=connection.prepareStatement("insert into account(acno,acholdernm,balance,date,mobno,adharno,emailid,imagepath) values(?,?,?,?,?,?,?,?)");
				

                statement.setInt(1,account.getAcno());
				statement.setString(2,account.getAcholdernm());
				statement.setInt(3,account.getBalance());
				statement.setString(4,account.getDate());
				statement.setLong(5,account.getMobno());
				statement.setLong(6,account.getAdharno());
				statement.setString(7,account.getImagepath());

				
				statement.executeUpdate();
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		public void updateAccount(Account account) 
		{
			try
			{
				Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/onlineexam3","root","root");
								
				PreparedStatement statement=connection.prepareStatement("update account set acholdernmname=? , balance=? ,date=?,mobno=?,adharno=?,emailid=?,imagepath=? where acno=?");
				
				statement.setString(1, account.getAcholdernm());
				statement.setInt(2, account.getBalance());
				statement.setLong(3, account.getMobno());
				statement.setLong(4, account.getAdharno());

				statement.setString(5, account.getDate());
				statement.setString(6, account.getImagepath());
                statement.setInt(7, account.getAcno());
				
				statement.executeUpdate();
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
	
		public Account getAccount(int acno)
		{

			Account account=new Account();
			
			try
			{
				Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3307/mydate","root","root");
				
				Statement statement=connection.createStatement();
			
				ResultSet resultset=statement.executeQuery("select * from account where acno="+acno);
				
				
				if(resultset.next())
				{
					
					String acholdernm=resultset.getString("acholdernm");
					int balance=resultset.getInt("balance");
					String date=resultset.getString("date");
					long mobno=resultset.getLong("mobno");
					long adharno=resultset.getLong("adharno");
					String emailid=resultset.getString("emailid");
					String imagepath=resultset.getString("imagepath");

				
					account.setAcno(acno);
					account.setAcholdernm(acholdernm);
					account.setBalance(balance);
					account.setDate(date);
					account.setMobno(mobno);
					account.setAdharno(adharno);
					account.setEmailid(emailid);
					account.setImagepath(imagepath);

				}
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			
			return account;
	
		}


		
		}
		
	
