package com.account.enttity;

public class Account {
	int acno;	
	String acholdernm;
	int balance;
	String date;
	long mobno;
	long adharno;
	String emailid;
	String imagepath;
	public int getAcno() {
		return acno;
	}
	public void setAcno(int acno) {
		this.acno = acno;
	}
	public String getAcholdernm() {
		return acholdernm;
	}
	public void setAcholdernm(String acholdernm) {
		this.acholdernm = acholdernm;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public long getMobno() {
		return mobno;
	}
	public void setMobno(long mobno) {
		this.mobno = mobno;
	}
	public long getAdharno() {
		return adharno;
	}
	public void setAdharno(long adharno) {
		this.adharno = adharno;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getImagepath() {
		return imagepath;
	}
	public void setImagepath(String imagepath) {
		this.imagepath = imagepath;
	}
	@Override
	public String toString() {
		return "Account [acno=" + acno + ", acholdernm=" + acholdernm + ", balance=" + balance + ", date=" + date
				+ ", mobno=" + mobno + ", adharno=" + adharno + ", emailid=" + emailid + ", imagepath=" + imagepath
				+ "]";
	}
	
	

}
