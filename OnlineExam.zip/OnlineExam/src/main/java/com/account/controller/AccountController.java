package com.account.controller;

import java.util.ArrayList;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.account.enttity.Account;
import com.accountdao.packages.AccountDao;

@RestController
public class AccountController {
	@Autowired
	AccountDao dao; // global variable
	
	
	ArrayList<Account> arrayList=new ArrayList<Account>();
	
	AccountController()
	{
		System.out.println("constructor called");
	}
	
	@PostConstruct
    public void showData()
    {	
		arrayList=dao.getAllAccounts();
    }
	
	@RequestMapping("getAllAccounts")
	public ModelAndView getAllAccounts()
	{	
	
		ArrayList<Account> arrayList=dao.getAllAccounts();
				
		ModelAndView modelAndView =new ModelAndView();
		modelAndView.setViewName("account");
		modelAndView.addObject("allAccounts",arrayList);
		
		return modelAndView;
		
	}
	
	@RequestMapping("deleteAccount/{acno}")
	public ModelAndView deleteEmployee(@PathVariable int acno)
	{
		dao.deleteAccount(acno);
		
		return getAllAccounts();
		
	}
	
	@RequestMapping("saveAccount")
	public ModelAndView saveAccount(Account account)
	{

		dao.saveAccount(account);
		
		return getAllAccounts();
		
	}
	
	@RequestMapping("updateAccount")
	public ModelAndView updateAccount(Account account)
	{
		System.out.println("Account from browser is " + account);
		
		dao.updateAccount(account);
		
		return getAllAccounts();
		
	}
	
	
	@RequestMapping("showAccount/{acno}")
	public ModelAndView showAccount(@PathVariable int acno)
	{

		ModelAndView modelAndView =new ModelAndView();
		
		modelAndView.setViewName("account");
		
		Account account=dao.getAccount(acno);
		
		modelAndView.addObject("account",account);
		
		ArrayList<Account> arrayList = dao.getAllAccounts();
		
		modelAndView.addObject("allAccounts",arrayList);
		
		return modelAndView;
		
	}

	@RequestMapping("viewAccount")
	public ModelAndView viewAccount(int acno)
	{

		ModelAndView modelAndView =new ModelAndView();
		
		modelAndView.setViewName("account");
		
		Account account=dao.getAccount(acno);
		
		modelAndView.addObject("account",account);
		
		ArrayList<Account> arrayList = dao.getAllAccounts();
		
		modelAndView.addObject("allAccounts",arrayList);
		
		return modelAndView;
		
	}
	
	@RequestMapping("showAccount")
	public ModelAndView showAccount()
	{
		ModelAndView modelAndView =new ModelAndView();
		
		modelAndView.setViewName("account");
		
		modelAndView.addObject("message","welcome to account management Application");
		
		modelAndView.addObject("allAccounts",arrayList);
		
		return  modelAndView;
	}


}

